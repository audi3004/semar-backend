const {
    Op,
} = require("sequelize");

const {
    Ijin,
    Petugas,
    Unit,
    Jabatan,
    Project,
    Gaji,
    Umk,
    KoefTmk,
    Status,
    Role,
} = require("../../models");

class IjinRepository {
    getStatusInclude() {
        return {
            model: Status,
            as: "status",
            required: true,

            attributes: [
                "id_status",
                "id_role",
                "kode_status",
                "nama_status",
                "urutan_status",
                "id_status_next",
                "id_status_revision",
                "id_status_rejected",
                "is_initial",
                "is_final",
                "is_active",
            ],

            include: [
                {
                    model: Role,
                    as: "role",
                    required: false,

                    attributes: [
                        "id_role",
                        "kode_role",
                        "nama_role",
                        "level_role",
                        "is_super_admin",
                        "is_active",
                    ],
                },

                {
                    model: Status,
                    as: "nextStatus",
                    required: false,

                    attributes: [
                        "id_status",
                        "id_role",
                        "kode_status",
                        "nama_status",
                    ],

                    include: [
                        {
                            model: Role,
                            as: "role",
                            required: false,

                            attributes: [
                                "id_role",
                                "kode_role",
                                "nama_role",
                            ],
                        },
                    ],
                },

                {
                    model: Status,
                    as: "revisionStatus",
                    required: false,

                    attributes: [
                        "id_status",
                        "id_role",
                        "kode_status",
                        "nama_status",
                    ],

                    include: [
                        {
                            model: Role,
                            as: "role",
                            required: false,

                            attributes: [
                                "id_role",
                                "kode_role",
                                "nama_role",
                            ],
                        },
                    ],
                },

                {
                    model: Status,
                    as: "rejectedStatus",
                    required: false,

                    attributes: [
                        "id_status",
                        "id_role",
                        "kode_status",
                        "nama_status",
                    ],
                },
            ],
        };
    }

    getPetugasInclude() {
        return {
            model: Petugas,
            as: "petugas",
            required: true,

            include: [
                {
                    model: Unit,
                    as: "unit",
                    required: false,
                },

                {
                    model: Jabatan,
                    as: "jabatan",
                    required: false,

                    include: [
                        {
                            model: Project,
                            as: "project",
                            required: false,
                        },
                    ],
                },

                {
                    model: Gaji,
                    as: "gaji",
                    required: false,

                    include: [
                        {
                            model: Umk,
                            as: "umk",
                            required: false,
                        },

                        {
                            model: KoefTmk,
                            as: "koefTmk",
                            required: false,
                        },
                    ],
                },
            ],
        };
    }

    getInclude() {
        return [
            this.getPetugasInclude(),
            this.getStatusInclude(),
        ];
    }

    async findAll(
        filters = {}
    ) {
        const where = {};

        if (filters.id_petugas) {
            where.id_petugas =
                filters.id_petugas;
        }

        if (filters.id_status) {
            where.id_status =
                filters.id_status;
        }

        if (filters.agenda) {
            where.agenda = {
                [Op.like]:
                    `%${filters.agenda}%`,
            };
        }

        if (filters.tanggal) {
            where.tanggal =
                filters.tanggal;
        }

        if (filters.tgl_selesai) {
            where.tgl_selesai =
                filters.tgl_selesai;
        }

        if (
            filters.tgl_mulai_filter &&
            filters.tgl_akhir_filter
        ) {
            where[Op.and] = [
                {
                    tanggal: {
                        [Op.lte]:
                            filters
                                .tgl_akhir_filter,
                    },
                },

                {
                    tgl_selesai: {
                        [Op.gte]:
                            filters
                                .tgl_mulai_filter,
                    },
                },
            ];
        }

        const statusInclude =
            this.getStatusInclude();

        if (filters.id_role) {
            statusInclude.where = {
                id_role:
                    filters.id_role,
            };
        }

        if (filters.kode_status) {
            statusInclude.where = {
                ...(statusInclude.where ||
                    {}),

                kode_status:
                    filters.kode_status,
            };
        }

        if (filters.is_final) {
            statusInclude.where = {
                ...(statusInclude.where ||
                    {}),

                is_final:
                    filters.is_final,
            };
        }

        return await Ijin.findAll({
            where,

            include: [
                this.getPetugasInclude(),
                statusInclude,
            ],

            order: [
                [
                    "tanggal",
                    "DESC",
                ],

                [
                    "id_ijin",
                    "DESC",
                ],
            ],
        });
    }

    async findById(
        id_ijin,
        transaction = null
    ) {
        return await Ijin.findByPk(
            id_ijin,
            {
                include:
                    this.getInclude(),
                transaction,
            }
        );
    }

    async findRawById(
        id_ijin
    ) {
        return await Ijin.findByPk(
            id_ijin
        );
    }

    async findPending() {
        const statusInclude =
            this.getStatusInclude();

        statusInclude.where = {
            is_final: "N",
            is_active: "Y",
        };

        return await Ijin.findAll({
            include: [
                this.getPetugasInclude(),
                statusInclude,
            ],

            order: [
                [
                    "tanggal",
                    "ASC",
                ],

                [
                    "id_ijin",
                    "ASC",
                ],
            ],
        });
    }

    async findByPetugas(
        id_petugas
    ) {
        return await Ijin.findAll({
            where: {
                id_petugas,
            },

            include:
                this.getInclude(),

            order: [
                [
                    "tanggal",
                    "DESC",
                ],

                [
                    "id_ijin",
                    "DESC",
                ],
            ],
        });
    }

    async findOverlapping(
        id_petugas,
        tanggal,
        tgl_selesai,
        excludeId = null
    ) {
        const statusInclude =
            this.getStatusInclude();

        statusInclude.where = {
            kode_status: {
                [Op.notIn]: [
                    "REJECTED",
                    "CANCELLED",
                ],
            },
        };

        const where = {
            id_petugas,

            tanggal: {
                [Op.lte]:
                    tgl_selesai,
            },

            tgl_selesai: {
                [Op.gte]:
                    tanggal,
            },
        };

        if (excludeId) {
            where.id_ijin = {
                [Op.ne]:
                    excludeId,
            };
        }

        return await Ijin.findOne({
            where,

            include: [
                statusInclude,
            ],
        });
    }

    async create(
        data,
        created_by = null,
        transaction = null
    ) {
        const result =
            await Ijin.create(
                {
                    ...data,
                    created_by,
                },
                {
                    transaction,
                }
            );

        return await this.findById(
            result.id_ijin,
            transaction
        );
    }

    async update(
        id_ijin,
        data,
        updated_by = null,
        transaction = null
    ) {
        await Ijin.update(
            {
                ...data,
                updated_by,
            },
            {
                where: {
                    id_ijin,
                },
                transaction,
            }
        );

        return await this.findById(
            id_ijin,
            transaction
        );
    }

    async updateStatus(
        id_ijin,
        id_status,
        updated_by = null,
        transaction = null
    ) {
        await Ijin.update(
            {
                id_status,
                updated_by,
            },
            {
                where: {
                    id_ijin,
                },
                transaction,
            }
        );

        return await this.findById(
            id_ijin,
            transaction
        );
    }

    async delete(
        id_ijin,
        transaction = null
    ) {
        return await Ijin.destroy({
            where: {
                id_ijin,
            },
            transaction,
        });
    }
}

module.exports =
    new IjinRepository();
