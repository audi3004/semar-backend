const lemburRepository = require(
    "./repository"
);

const petugasRepository = require(
    "../petugas/repository"
);

const statusRepository = require(
    "../status/repository"
);

const logLemburService = require(
    "../logLembur/service"
);

const {
    sequelize,
} = require("../../models");

const AppError = require(
    "../../utils/AppError"
);

class LemburService {
    getSnapshot(lembur) {
        if (!lembur) {
            return null;
        }

        const snapshot =
            typeof lembur.toJSON ===
            "function"
                ? lembur.toJSON()
                : {
                    ...lembur,
                };

        delete snapshot.logs;

        return snapshot;
    }

    async createLog(
        {
            id_lembur,
            id_status_sebelum =
                null,
            id_status_sesudah =
                null,
            aksi,
            keterangan = null,
            data_sebelum = null,
            data_sesudah = null,
            created_by = null,
        },
        transaction
    ) {
        return await logLemburService
            .create(
                {
                    id_lembur,
                    id_status_sebelum,
                    id_status_sesudah,
                    aksi,
                    keterangan,
                    data_sebelum,
                    data_sesudah,
                    created_by,
                },
                transaction
            );
    }

    normalizeText(value) {
        if (
            value === undefined ||
            value === null
        ) {
            return value;
        }

        return String(value)
            .trim()
            .replace(/\s+/g, " ");
    }

    normalizeNullableText(
        value
    ) {
        if (
            value === undefined
        ) {
            return undefined;
        }

        if (
            value === null
        ) {
            return null;
        }

        const result =
            String(value).trim();

        return result || null;
    }

    normalizeDate(value) {
        if (!value) {
            return value;
        }

        if (
            value instanceof Date
        ) {
            return value
                .toISOString()
                .slice(0, 10);
        }

        return String(value)
            .slice(0, 10);
    }

    normalizeTime(value) {
        if (!value) {
            return value;
        }

        const time =
            String(value).trim();

        if (
            /^\d{2}:\d{2}$/.test(
                time
            )
        ) {
            return `${time}:00`;
        }

        return time;
    }

    timeToMinutes(time) {
        const [
            hour,
            minute,
            second = 0,
        ] = String(time)
            .split(":")
            .map(Number);

        if (
            Number.isNaN(hour) ||
            Number.isNaN(minute) ||
            Number.isNaN(second)
        ) {
            throw new AppError(
                "Format jam lembur tidak valid",
                400
            );
        }

        return (
            hour * 60 +
            minute +
            second / 60
        );
    }

    validateTimeRange(
        jam_mulai,
        jam_selesai
    ) {
        const startMinutes =
            this.timeToMinutes(
                jam_mulai
            );

        const endMinutes =
            this.timeToMinutes(
                jam_selesai
            );

        if (
            startMinutes >=
            endMinutes
        ) {
            throw new AppError(
                "Jam mulai harus lebih kecil dari jam selesai",
                400
            );
        }
    }

    calculateTotalHours(
        jam_mulai,
        jam_selesai
    ) {
        const startMinutes =
            this.timeToMinutes(
                jam_mulai
            );

        const endMinutes =
            this.timeToMinutes(
                jam_selesai
            );

        const totalMinutes =
            endMinutes -
            startMinutes;

        return Number(
            (
                totalMinutes / 60
            ).toFixed(2)
        );
    }

    async checkLembur(
        id_lembur
    ) {
        const lembur =
            await lemburRepository
                .findById(
                    id_lembur
                );

        if (!lembur) {
            throw new AppError(
                "Data lembur tidak ditemukan",
                404
            );
        }

        return lembur;
    }

    async checkPetugas(
        id_petugas
    ) {
        const petugas =
            await petugasRepository
                .findById(
                    id_petugas
                );

        if (!petugas) {
            throw new AppError(
                "Data petugas tidak ditemukan",
                404
            );
        }

        if (
            petugas.is_active !==
            "Y"
        ) {
            throw new AppError(
                "Petugas sedang tidak aktif",
                400
            );
        }

        return petugas;
    }

    async getInitialStatus() {
        const status =
            await statusRepository
                .findInitial();

        if (!status) {
            throw new AppError(
                "Status awal belum dikonfigurasi pada Master Status",
                500
            );
        }

        if (
            status.is_active !==
            "Y"
        ) {
            throw new AppError(
                "Status awal sedang tidak aktif",
                500
            );
        }

        return status;
    }

    getUserRoleId(user) {
        return (
            user?.id_role ??
            user?.role?.id_role ??
            null
        );
    }

    isSuperAdmin(user) {
        return (
            user?.is_super_admin ===
            "Y" ||
            user?.role
                ?.is_super_admin ===
            "Y" ||
            user?.kode_role ===
            "SUPER_ADMIN" ||
            user?.role?.kode_role ===
            "SUPER_ADMIN"
        );
    }

    validateAuthenticatedUser(
        user
    ) {
        if (!user) {
            throw new AppError(
                "User belum terautentikasi",
                401
            );
        }
    }

    validateStatusAuthority(
        status,
        user
    ) {
        this.validateAuthenticatedUser(
            user
        );

        if (
            this.isSuperAdmin(user)
        ) {
            return;
        }

        if (!status.id_role) {
            throw new AppError(
                "Status ini tidak memiliki role pemroses",
                403
            );
        }

        const idRoleUser =
            this.getUserRoleId(
                user
            );

        if (!idRoleUser) {
            throw new AppError(
                "Role user tidak ditemukan",
                403
            );
        }

        if (
            Number(
                status.id_role
            ) !==
            Number(idRoleUser)
        ) {
            throw new AppError(
                `Transaksi ini hanya dapat diproses oleh role ${status.role
                    ?.nama_role ||
                status.role
                    ?.kode_role ||
                status.id_role
                }`,
                403
            );
        }
    }

    validateEditableStatus(
        status,
        user
    ) {
        if (
            status.is_final ===
            "Y"
        ) {
            throw new AppError(
                "Lembur dengan status final tidak dapat diubah",
                400
            );
        }

        this.validateStatusAuthority(
            status,
            user
        );

        const editableStatuses = [
            "DRAFT",
            "REVISION",
        ];

        if (
            !editableStatuses.includes(
                status.kode_status
            ) &&
            !this.isSuperAdmin(user)
        ) {
            throw new AppError(
                "Lembur hanya dapat diubah ketika berstatus DRAFT atau REVISION",
                400
            );
        }
    }

    async ensureNoOverlap(
        id_petugas,
        tgl_lembur,
        jam_mulai,
        jam_selesai,
        excludeId = null
    ) {
        const existingLembur =
            await lemburRepository
                .findOverlapping(
                    id_petugas,
                    tgl_lembur,
                    jam_mulai,
                    jam_selesai,
                    excludeId
                );

        if (existingLembur) {
            throw new AppError(
                "Masih terdapat pengajuan lembur pada rentang jam tersebut",
                409
            );
        }
    }

    async checkDestinationStatus(
        id_status,
        fieldName
    ) {
        const status =
            await statusRepository
                .findRawById(
                    id_status
                );

        if (!status) {
            throw new AppError(
                `${fieldName} tidak ditemukan`,
                404
            );
        }

        if (
            status.is_active !==
            "Y"
        ) {
            throw new AppError(
                `${fieldName} sedang tidak aktif`,
                400
            );
        }

        return status;
    }

    async findAll(
        filters = {}
    ) {
        return await lemburRepository
            .findAll({
                id_petugas:
                    filters.id_petugas,

                id_petugas_cuti:
                    filters.id_petugas_cuti,

                id_status:
                    filters.id_status,

                id_role:
                    filters.id_role,

                tgl_lembur:
                    this.normalizeDate(
                        filters.tgl_lembur
                    ),

                kategori_lembur:
                    this.normalizeText(
                        filters.kategori_lembur
                    ),

                kode_status:
                    filters.kode_status
                        ? String(
                            filters.kode_status
                        )
                            .trim()
                            .toUpperCase()
                        : undefined,

                is_final:
                    filters.is_final
                        ? String(
                            filters.is_final
                        )
                            .trim()
                            .toUpperCase()
                        : undefined,

                tgl_awal:
                    this.normalizeDate(
                        filters.tgl_awal
                    ),

                tgl_akhir:
                    this.normalizeDate(
                        filters.tgl_akhir
                    ),
            });
    }

    async findById(
        id_lembur
    ) {
        return await this.checkLembur(
            id_lembur
        );
    }

    async findPending() {
        return await lemburRepository
            .findPending();
    }

    async findByPetugas(
        id_petugas
    ) {
        await this.checkPetugas(
            id_petugas
        );

        return await lemburRepository
            .findByPetugas(
                id_petugas
            );
    }

    async create(
        data,
        user = null
    ) {
        const tglLembur =
            this.normalizeDate(
                data.tgl_lembur
            );

        const jamMulai =
            this.normalizeTime(
                data.jam_mulai
            );

        const jamSelesai =
            this.normalizeTime(
                data.jam_selesai
            );

        this.validateTimeRange(
            jamMulai,
            jamSelesai
        );

        await this.checkPetugas(
            data.id_petugas
        );

        if (data.id_petugas_cuti) {
            await this.checkPetugas(
                data.id_petugas_cuti
            );
        }

        await this.ensureNoOverlap(
            data.id_petugas,
            tglLembur,
            jamMulai,
            jamSelesai
        );

        const initialStatus =
            await this
                .getInitialStatus();

        if (
            user &&
            initialStatus.id_role
        ) {
            this.validateStatusAuthority(
                initialStatus,
                user
            );
        }

        const idLembur =
            await sequelize.transaction(
                async (
                    transaction
                ) => {
                    const lembur =
                        await lemburRepository
                            .create(
                {
                    id_petugas:
                        data.id_petugas,

                    id_petugas_cuti:
                        data.id_petugas_cuti ??
                        null,

                    id_status:
                        initialStatus
                            .id_status,

                    tgl_lembur:
                        tglLembur,

                    jam_mulai:
                        jamMulai,

                    jam_selesai:
                        jamSelesai,

                    total_jam:
                        this.calculateTotalHours(
                            jamMulai,
                            jamSelesai
                        ),

                    kategori_lembur:
                        this.normalizeText(
                            data.kategori_lembur
                        ),

                    detail_pekerjaan_lembur:
                        this.normalizeNullableText(
                            data.detail_pekerjaan_lembur
                        ),

                    foto_kegiatan_1:
                        data.foto_kegiatan_1,

                    foto_kegiatan_2:
                        data.foto_kegiatan_2,

                    surat_perintah_lembur:
                        data.surat_perintah_lembur,

                    keterangan:
                        this.normalizeNullableText(
                            data.keterangan
                        ),
                },

                user?.id_user ??
                null,
                transaction
            );

                    await this.createLog(
                        {
                            id_lembur:
                                lembur.id_lembur,
                            id_status_sesudah:
                                lembur.id_status,
                            aksi: "CREATE",
                            keterangan:
                                "Pengajuan lembur dibuat",
                            data_sesudah:
                                this.getSnapshot(
                                    lembur
                                ),
                            created_by:
                                user?.id_user ??
                                null,
                        },
                        transaction
                    );

                    return lembur
                        .id_lembur;
                }
            );

        return await lemburRepository
            .findById(idLembur);
    }

    async update(
        id_lembur,
        data,
        user = null
    ) {
        const currentLembur =
            await this.checkLembur(
                id_lembur
            );

        this.validateEditableStatus(
            currentLembur.status,
            user
        );

        const idPetugas =
            data.id_petugas ??
            currentLembur.id_petugas;

        const idPetugasCuti =
            data.id_petugas_cuti !==
                undefined
                ? data.id_petugas_cuti
                : currentLembur
                    .id_petugas_cuti;

        const tglLembur =
            this.normalizeDate(
                data.tgl_lembur ??
                currentLembur
                    .tgl_lembur
            );

        const jamMulai =
            this.normalizeTime(
                data.jam_mulai ??
                currentLembur
                    .jam_mulai
            );

        const jamSelesai =
            this.normalizeTime(
                data.jam_selesai ??
                currentLembur
                    .jam_selesai
            );

        this.validateTimeRange(
            jamMulai,
            jamSelesai
        );

        if (
            data.id_petugas !==
            undefined
        ) {
            await this.checkPetugas(
                idPetugas
            );
        }

        if (
            data.id_petugas_cuti !==
                undefined &&
            idPetugasCuti !== null
        ) {
            await this.checkPetugas(
                idPetugasCuti
            );
        }

        await this.ensureNoOverlap(
            idPetugas,
            tglLembur,
            jamMulai,
            jamSelesai,
            id_lembur
        );

        await sequelize.transaction(
            async (
                transaction
            ) => {
                const updatedLembur =
                    await lemburRepository
                        .update(
                            id_lembur,

                {
                    id_petugas:
                        idPetugas,

                    id_petugas_cuti:
                        idPetugasCuti,

                    tgl_lembur:
                        tglLembur,

                    jam_mulai:
                        jamMulai,

                    jam_selesai:
                        jamSelesai,

                    total_jam:
                        this.calculateTotalHours(
                            jamMulai,
                            jamSelesai
                        ),

                    kategori_lembur:
                        data.kategori_lembur !==
                            undefined
                            ? this.normalizeText(
                                data.kategori_lembur
                            )
                            : currentLembur
                                .kategori_lembur,

                    detail_pekerjaan_lembur:
                        data.detail_pekerjaan_lembur !==
                            undefined
                            ? this.normalizeNullableText(
                                data.detail_pekerjaan_lembur
                            )
                            : currentLembur
                                .detail_pekerjaan_lembur,

                    foto_kegiatan_1:
                        data.foto_kegiatan_1 ??
                        currentLembur
                            .foto_kegiatan_1,

                    foto_kegiatan_2:
                        data.foto_kegiatan_2 ??
                        currentLembur
                            .foto_kegiatan_2,

                    surat_perintah_lembur:
                        data.surat_perintah_lembur ??
                        currentLembur
                            .surat_perintah_lembur,

                    keterangan:
                        data.keterangan !==
                            undefined
                            ? this.normalizeNullableText(
                                data.keterangan
                            )
                            : currentLembur
                                .keterangan,
                },

                user?.id_user ??
                null,
                transaction
            );

                await this.createLog(
                    {
                        id_lembur,
                        id_status_sebelum:
                            currentLembur
                                .id_status,
                        id_status_sesudah:
                            updatedLembur
                                .id_status,
                        aksi: "UPDATE",
                        keterangan:
                            "Data pengajuan lembur diperbarui",
                        data_sebelum:
                            this.getSnapshot(
                                currentLembur
                            ),
                        data_sesudah:
                            this.getSnapshot(
                                updatedLembur
                            ),
                        created_by:
                            user?.id_user ??
                            null,
                    },
                    transaction
                );
            }
        );

        return await lemburRepository
            .findById(id_lembur);
    }

    async moveToNextStatus(
        id_lembur,
        user
    ) {
        const lembur =
            await this.checkLembur(
                id_lembur
            );

        if (
            lembur.status.is_final ===
            "Y"
        ) {
            throw new AppError(
                "Lembur sudah berada pada status final",
                400
            );
        }

        this.validateStatusAuthority(
            lembur.status,
            user
        );

        if (
            !lembur.status
                .id_status_next
        ) {
            throw new AppError(
                "Status berikutnya belum dikonfigurasi",
                400
            );
        }

        const nextStatus =
            await this
                .checkDestinationStatus(
                    lembur.status
                        .id_status_next,
                    "Status berikutnya"
                );

        await this.updateStatusWithLog(
            lembur,
            nextStatus,
            "NEXT",
            "Status lembur diproses ke tahap berikutnya",
            user
        );

        return await lemburRepository
            .findById(id_lembur);
    }

    async moveToRevision(
        id_lembur,
        user
    ) {
        const lembur =
            await this.checkLembur(
                id_lembur
            );

        if (
            lembur.status.is_final ===
            "Y"
        ) {
            throw new AppError(
                "Lembur dengan status final tidak dapat direvisi",
                400
            );
        }

        this.validateStatusAuthority(
            lembur.status,
            user
        );

        if (
            !lembur.status
                .id_status_revision
        ) {
            throw new AppError(
                "Status revisi belum dikonfigurasi",
                400
            );
        }

        const revisionStatus =
            await this
                .checkDestinationStatus(
                    lembur.status
                        .id_status_revision,
                    "Status revisi"
                );

        await this.updateStatusWithLog(
            lembur,
            revisionStatus,
            "REVISION",
            "Pengajuan lembur dikembalikan untuk direvisi",
            user
        );

        return await lemburRepository
            .findById(id_lembur);
    }

    async moveToRejected(
        id_lembur,
        user
    ) {
        const lembur =
            await this.checkLembur(
                id_lembur
            );

        if (
            lembur.status.is_final ===
            "Y"
        ) {
            throw new AppError(
                "Lembur sudah berada pada status final",
                400
            );
        }

        this.validateStatusAuthority(
            lembur.status,
            user
        );

        if (
            !lembur.status
                .id_status_rejected
        ) {
            throw new AppError(
                "Status penolakan belum dikonfigurasi",
                400
            );
        }

        const rejectedStatus =
            await this
                .checkDestinationStatus(
                    lembur.status
                        .id_status_rejected,
                    "Status penolakan"
                );

        await this.updateStatusWithLog(
            lembur,
            rejectedStatus,
            "REJECT",
            "Pengajuan lembur ditolak",
            user
        );

        return await lemburRepository
            .findById(id_lembur);
    }

    async updateStatusWithLog(
        currentLembur,
        destinationStatus,
        aksi,
        keterangan,
        user
    ) {
        await sequelize.transaction(
            async (
                transaction
            ) => {
                const updatedLembur =
                    await lemburRepository
                        .updateStatus(
                            currentLembur
                                .id_lembur,
                            destinationStatus
                                .id_status,
                            user?.id_user ??
                            null,
                            transaction
                        );

                await this.createLog(
                    {
                        id_lembur:
                            currentLembur
                                .id_lembur,
                        id_status_sebelum:
                            currentLembur
                                .id_status,
                        id_status_sesudah:
                            destinationStatus
                                .id_status,
                        aksi,
                        keterangan,
                        data_sebelum:
                            this.getSnapshot(
                                currentLembur
                            ),
                        data_sesudah:
                            this.getSnapshot(
                                updatedLembur
                            ),
                        created_by:
                            user?.id_user ??
                            null,
                    },
                    transaction
                );
            }
        );
    }

    async delete(
        id_lembur,
        user
    ) {
        const lembur =
            await this.checkLembur(
                id_lembur
            );

        this.validateEditableStatus(
            lembur.status,
            user
        );

        await sequelize.transaction(
            async (
                transaction
            ) => {
                await this.createLog(
                    {
                        id_lembur,
                        id_status_sebelum:
                            lembur.id_status,
                        aksi: "DELETE",
                        keterangan:
                            "Pengajuan lembur dihapus",
                        data_sebelum:
                            this.getSnapshot(
                                lembur
                            ),
                        created_by:
                            user?.id_user ??
                            null,
                    },
                    transaction
                );

                await lemburRepository
                    .delete(
                        id_lembur,
                        transaction
                    );
            }
        );

        return true;
    }
}

module.exports =
    new LemburService();
