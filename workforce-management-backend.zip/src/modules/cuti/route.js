const express = require(
    "express"
);

const router =
    express.Router();

const controller = require(
    "./controller"
);

const schema = require(
    "./validator"
);

const validate = require(
    "../../middlewares/validator"
);

router.get(
    "/",
    validate(
        schema.query,
        "query"
    ),
    controller.findAll
);

router.get(
    "/pending",
    controller.findPending
);

router.get(
    "/petugas/:id",
    validate(
        schema.petugasParams,
        "params"
    ),
    controller.findByPetugas
);

router.get(
    "/:id",
    validate(
        schema.params,
        "params"
    ),
    controller.findById
);

router.post(
    "/",
    validate(
        schema.create
    ),
    controller.create
);

router.put(
    "/:id",
    validate(
        schema.params,
        "params"
    ),
    validate(
        schema.update
    ),
    controller.update
);

router.patch(
    "/:id/next",
    validate(
        schema.params,
        "params"
    ),
    controller.next
);

router.patch(
    "/:id/revision",
    validate(
        schema.params,
        "params"
    ),
    controller.revision
);

router.patch(
    "/:id/reject",
    validate(
        schema.params,
        "params"
    ),
    controller.reject
);

router.delete(
    "/:id",
    validate(
        schema.params,
        "params"
    ),
    controller.delete
);

module.exports = router;