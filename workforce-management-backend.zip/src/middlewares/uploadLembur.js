const fs = require("fs");
const path = require("path");
const multer = require("multer");

const uploadDirectory = path.join(
    process.cwd(),
    "uploads",
    "lembur"
);

fs.mkdirSync(uploadDirectory, {
    recursive: true,
});

const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, uploadDirectory);
    },
    filename: (req, file, callback) => {
        const extension = path
            .extname(file.originalname)
            .toLowerCase();
        const uniqueName = `${Date.now()}-${Math.round(
            Math.random() * 1e9
        )}`;

        callback(
            null,
            `${file.fieldname}-${uniqueName}${extension}`
        );
    },
});

const imageMimeTypes = [
    "image/jpeg",
    "image/jpg",
    "image/png",
];
const documentMimeTypes = [
    ...imageMimeTypes,
    "application/pdf",
];

const fileFilter = (req, file, callback) => {
    const allowed =
        file.fieldname === "surat_perintah_lembur"
            ? documentMimeTypes
            : imageMimeTypes;

    if (!allowed.includes(file.mimetype)) {
        const message =
            file.fieldname === "surat_perintah_lembur"
                ? "Surat perintah lembur harus berformat PDF, JPG, JPEG, atau PNG"
                : "Foto kegiatan harus berformat JPG, JPEG, atau PNG";

        return callback(new Error(message), false);
    }

    callback(null, true);
};

module.exports = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024,
        files: 3,
    },
}).fields([
    { name: "foto_kegiatan_1", maxCount: 1 },
    { name: "foto_kegiatan_2", maxCount: 1 },
    { name: "surat_perintah_lembur", maxCount: 1 },
]);
