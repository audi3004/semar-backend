const response = require("../utils/response");

const fields = [
    "foto_kegiatan_1",
    "foto_kegiatan_2",
    "surat_perintah_lembur",
];

module.exports = (required = false) => {
    return (req, res, next) => {
        const missing = fields.filter(
            (field) => !req.files?.[field]?.[0]
        );

        if (required && missing.length) {
            return response.validation(
                res,
                missing.map((field) => ({
                    field,
                    message: `${field.replace(/_/g, " ")} wajib diunggah`,
                })),
                "Validasi file gagal"
            );
        }

        for (const field of fields) {
            const file = req.files?.[field]?.[0];
            if (file) {
                req.body[field] = `/uploads/lembur/${file.filename}`;
            }
        }

        next();
    };
};
