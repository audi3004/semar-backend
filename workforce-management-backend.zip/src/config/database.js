const { Sequelize } = require("sequelize");
require("dotenv").config();

const sequelize = new Sequelize(
    process.env.DB_NAME,
    process.env.DB_USER,
    process.env.DB_PASSWORD,
    {
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        dialect: process.env.DB_DIALECT,

        logging: false,

        timezone: "+07:00",

        define: {
            freezeTableName: true,
            timestamps: false,
        },

        pool: {
            max: 20,
            min: 5,
            acquire: 30000,
            idle: 10000,
        },
    }
);

module.exports = sequelize;