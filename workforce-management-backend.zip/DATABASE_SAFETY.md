# Database Safety

Server aplikasi tidak menjalankan `sequelize.sync()`, `alter`, atau
`force` ketika startup. Perubahan schema harus dilakukan secara eksplisit
melalui migration setelah backup database dibuat.

## Urutan aman

1. Buat backup database.
2. Pastikan target database pada `.env` sudah benar.
3. Periksa migration yang belum dijalankan:

   ```bash
   npm run db:migrate:status
   ```

4. Jalankan migration:

   ```bash
   npm run db:migrate
   ```

5. Jalankan seeder Super Admin:

   ```bash
   npm run seed:super-admin
   ```

   Atau, untuk menyiapkan seluruh master data demo, workflow approval,
   module, access module, serta Super Admin sekaligus:

   ```bash
   npm run seed:initialize
   ```

6. Jalankan aplikasi:

   ```bash
   npm start
   ```

## Super Admin

- Username default: `superadmin`
- Password default: `SuperAdmin123!!`

Nilai tersebut dapat diganti melalui `SUPER_ADMIN_USERNAME` dan
`SUPER_ADMIN_PASSWORD` pada `.env` sebelum seeder dijalankan.

Seeder bersifat idempotent. Menjalankannya kembali akan mengaktifkan akun,
memastikan role `SUPER_ADMIN`, mereset password, dan mencabut refresh token
lama dari akun tersebut.

`seed:initialize` juga bersifat idempotent dan dijalankan dalam satu database
transaction. Seeder tersebut memperbarui record demo yang sama tanpa membuat
duplikasi, tetapi tetap akan mereset password Super Admin ke nilai konfigurasi
ketika dijalankan kembali.

Segera ganti password default setelah login pertama pada environment yang
dapat diakses pihak lain.

## Mengosongkan data pengujian

Untuk menghapus seluruh isi tabel aplikasi tanpa menghapus struktur tabel
dan riwayat migration (`SequelizeMeta`), jalankan:

```bash
npm run db:clear
```

Perintah ini bersifat destruktif. Pastikan database pada `.env` benar dan
buat backup apabila datanya masih diperlukan. Setelah itu, master data dapat
dibuat kembali dengan `npm run seed:initialize`.
